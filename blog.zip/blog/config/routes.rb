Rails.application.routes.draw do
  resources :posts
  root "articles#index"

  resources :articles
end
