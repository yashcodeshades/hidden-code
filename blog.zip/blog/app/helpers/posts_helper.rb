module PostsHelper
		def test
		"I am test and helper"
	end
end
